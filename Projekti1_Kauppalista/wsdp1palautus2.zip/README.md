# Project 1: Shared shopping list

Write the documentation of your project here. Do not include your personal
details (e.g. name or student number).

Remember to include the address of the online location where your project is
running as it is a key part of the submission.

This application provides a shared shopping list where users can create shopping lists and add items to those shopping lists. These items can be marked as collected and when you have completed she shopping for an indiviual list you can deactivate the list.

Unfortunately for I dont have a credit card so I cant deply my application online.

The application can easily be run locally using the docker-compose up command.


